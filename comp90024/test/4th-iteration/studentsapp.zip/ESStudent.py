from ESDocument import ESDocument

class ESStudent(ESDocument):

    def __init__(self, commons, req):
        super(ESStudent, self).__init__(commons, req, 'student')
