from elasticsearch8 import Elasticsearch
from datetime import datetime
from flask import current_app, request
import requests
import json
# from elasticsearch_dsl import Search
# import json

def config(k):
    with open(f'/configs/default/shared-data/{k}', 'r') as f:
        return f.read()

def main():
    # Connect to the local elastic server
    client = Elasticsearch (
        'https://elasticsearch-master.elastic.svc.cluster.local:9200',
        verify_certs= False,
        basic_auth=('elastic','elastic') #TODO replace with yaml reference
    )
    response = requests.get('http://router.fission/fission-function/wharvester').json()
    weather_data = response["observations"]["data"]
    # print("beofre return")
    # return str(weather_data)
    print("before insertion")
    for data in weather_data:
        print("inserted one")
        res = client.index(
        index='weather_data',
        id = data['aifstime_utc']+data['history_product'],
        document=data
        )
    return f"finished. Inserted {len(weather_data)} entries"
    
        # for health in request.get_json(force=True):
        # res = client.index(
        #     index='health',
        #     id=f'{datetime.now}',
        #     body=health
        # )
    #     current_app.logger.info(f'Indexed health ')    
           
    # response = client.index(index="test-wh-index", id=3, document=doc)
    # return(f"okay Index created: {res}\n")


    # # test connection
    # if client.ping():
    #     return("Connected to Elasticsearch!")
    # else:
    #     return("Could not connect to Elasticsearch.")
    
# %%
# import json
# file = open('local_weather_data.json', 'r')
# a= json.load(file)
# a = json.load("local_weather_data.json")
# %%
